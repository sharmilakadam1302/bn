(function($, w, d){
    var tabs = function( $el ){
        
        $el.find( 'li > a' ).on( 'click', function(e){
            e.preventDefault();

            $el.find('li').removeClass('active');
            $('.tab-container .tab-content').removeClass('active');

            $(this).closest( 'li' ).addClass( 'active' );

            $( $(this).attr('href') ).addClass( 'active' );
        });
    };

    var buyOrSell = function(e){
        e.preventDefault();

        if( !confirm( 'Are you sure?') ) return;

        $('#message .message').remove();
        $('.table-buy').empty();

        var action = $(this).data('action');

        $.ajax({
            url : 'inc/ajax.php?action=' + action,
            processData: false,
            contentType: false,
            type : 'post',
            dataType : 'json',
            data : new FormData( d.getElementById( 'form-buy') ),
            beforeSend : function(){
                $('.btn-buysell').prop( 'disabled', true );
            },
            complete : function(){
                $('.btn-buysell').prop('disabled', false);
            },
            success : function( json ){
                console.log( json );

                if( typeof json.message !== 'undefined' ){
                    if( json.status == 'success' ){
                        $('#message').html('<div class="message success">' + json.message + '</div>');
                    }else{
                        $('#message').html( '<div class="message error">' + json.message + '</div>' );
                    }
                }

                if (json.data !== null) {
                    $.each( json.data, function(k, v){
                        if (k == 'status' || k == 'price' || k == 'executedQty' ){
                            var html = '<tr class="row-buy"><th>' + k + '</th><td>' + v + '</td></tr>';
                            $('.table-buy').append(html);
                        }
                        
                        if (k == 'symbol') {
                            $('input[name="symbol"]').val( v );
                        }

                        if( k == 'fills' && v.length > 0 ){
                            $('input[name="price"]').val( v[0].price );
                        }

                        if (k == 'executedQty'){
                            $('input[name="quantity"]').val( v );
                        }


                        if( k == 'side' ){
                            if( v == 'SELL' ){
                                $('#btn-oco').data( 'action', 'buyoco' );
                                $('#btn-oco').text( 'Buy' );
                            }else{
                                $('#btn-oco').data( 'action', 'selloco' );
                                $('#btn-oco').text( 'Sell' );
                            }
                        }

                        if( k == 'orderId' ){
                            $('input[name="orderId"]').val( v );
                        }
                    });

                    $('#btn-oco, #btn-ammend').prop('disabled', false);
                    $('#btn-ammend').data('type', action);
                    
                }
            },
            error : function( xhr ){
                console.log( xhr.reponseText );
            }
        });
    };

    var oco = function( e ){
        e.preventDefault();

        if (!confirm('Are you sure?')) return;

        $('#message .message').remove();
        $('.table-buy').empty();

        var action = $(this).data('action');

        $.ajax({
            url : 'inc/ajax.php?action=' + action,
            processData: false,
            contentType: false,
            type : 'post',
            dataType : 'json',
            data : new FormData( d.getElementById( 'form-oco') ),
            beforeSend : function(){
                $('#btn-oco').prop( 'disabled', true );
            },
            complete : function(){
                $('#btn-oco').prop('disabled', false);
            },
            success : function( json ){
                console.log( json );

                if( json.status == 'error' ){
                    $('#btn-oco').prop('disabled', false);
                }

                if (typeof json.message !== 'undefined') {
                    if (json.status == 'success') {
                        $('#message').html('<div class="message success">' + json.message + '</div>');
                    } else {
                        $('#message').html('<div class="message error">' + json.message + '</div>');
                    }
                }

                if( json.status == 'success' && json.data !== null ){
                    if (typeof json.data.orderReports !== 'undefined' ){
                        for (var i = 0; i < json.data.orderReports.length; i++ ){
                            var html = '<tr><th>OCO Order Id</th><td>' + json.data.orderReports[i].clientOrderId + '</td></tr>';
                            html += '<tr><th>price</th><td>' + json.data.orderReports[i].price + '</td></tr>';
                            html += '<tr><th>executedQty</th><td>' + json.data.orderReports[i].executedQty + '</td></tr>';
                            html += '<tr><th>status</th><td>' + json.data.orderReports[i].status + '</td></tr>';

                            $('.table-buy').append(html);
                        }
                    }
                }
            },
            error: function (xhr) {
                console.log(xhr.reponseText);
            }
        });
    };

    var ammend = function( e ){
        e.preventDefault();

        if( !confirm( 'Are you sure?') ) return;

        $('#message .message').remove();
        $('.table-buy').empty();

        $.ajax({
            url : 'inc/ajax.php?action=ammend',
            processData: false,
            contentType: false,
            type : 'post',
            dataType : 'json',
            data : new FormData( d.getElementById( 'form-buy') ),
            beforeSend : function(){
                $('#btn-ammend').prop( 'disabled', true );
            },
            complete : function(){
                // $('#btn-ammend').prop('disabled', false);
            },
            success : function( json ){
                console.log( json );

                if( typeof json.message !== 'undefined' ){
                    if( json.status == 'success' ){
                        $('#message').html('<div class="message success">' + json.message + '</div>');
                    }else{
                        $('#message').html( '<div class="message error">' + json.message + '</div>' );
                    }
                }

                if (json.status == 'success' && json.data !== null) {
                    if (json.data.status == 'CANCELED' ){
                        $('input[name="newClientOrderId"]').val( json.updatedOrderId );
                        $('#form-oco-message').html('<div class="message success">Cancelled order ' + json.data.origClientOrderId + ', placing new one' );

                        $('.btn-buysell[data-action="' + $('#btn-ammend').data('type') + '"]').trigger( 'click' );

                        setTimeout( function(){
                            $('#form-oco-message').html( '' );
                        }, 1400 );
                    }
                }
            },
            error : function( xhr ){
                console.log( xhr.reponseText );
            }
        });
    };

    var balance = function(e){
        e.preventDefault();

        $('#message-balance .message').remove();
        $('.table-balance .row-balance').remove();

        $.ajax({
            url : 'inc/ajax.php?action=balance',
            processData: false,
            contentType: false,
            type : 'post',
            dataType : 'json',
            data: new FormData(d.getElementById('form-balance')),
            beforeSend : function(){
                $('#btn-submit-form-balance').prop( 'disabled', true );
            },
            complete : function(){
                $('#btn-submit-form-balance').prop('disabled', false);
            },
            success : function( json ){
                console.log( json );

                if( typeof json.message !== 'undefined' ){
                    if( json.status == 'success' ){
                        $('#message-balance').html('<div class="message success">' + json.message + '</div>');
                    }else{
                        $('#message-balance').html( '<div class="message error">' + json.message + '</div>' );
                    }
                }

                if( json.status == 'success' && json.data !== null ){
                    
                    if (typeof json.data.data.totalAssetOfBtc !== 'undefined') {
                        $('#cell-totalAssetOfBtc').text(json.data.data.totalAssetOfBtc);
                    }

                    if (typeof json.data.data.balances !== 'undefined') {
                        for (var i = 0; i < json.data.balances.length; i++ ){
                            var html = '<tr class="row-balance"><td>';
                            html += json.data.balances[i].asset + '</td><td>';
                            html += json.data.balances[i].free + '</td><td>';
                            html += json.data.balances[i].locked + '</td></tr>';
                            $('.table-balance').append( html );
                        }
                    }
                }
            },
            error : function( xhr ){
                console.log( xhr.reponseText );
            }
        });
    };

    $.fn.tabs = function(){
        $(this).each( function(){
            tabs( $(this) );
        });
    };

    $(function(){
        $('.tablist').tabs();

        $('#form-buy').on( 'submit', function(){
            return;
        } );

        $('#form-oco').on( 'submit', function(){
            return;
        } );

        $('.btn-buysell').on( 'click', buyOrSell );
        $('#btn-oco').on( 'click', oco );

        $('#btn-ammend').on( 'click', ammend );

        $('#form-balance').on( 'submit', balance );
    });
})(jQuery, window, document);