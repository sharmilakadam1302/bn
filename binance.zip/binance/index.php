<?php

namespace Binance;

use Binance\Inc\Config;

use function Binance\Inc\generateOrderID;

/**
 * @package binanc
 * @author Roy Parthapratim <me.partha04@gmail.com>
 * @version 1.0.0
 */

require_once 'inc/functions.php';
require_once 'inc/config.php';

?>
<!DOCTYPE html>
<html lang="en-US" dir="ltr">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Binance App</title>
    <link rel="stylesheet" href="assets/css/base.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
</head>

<body>
    <div class="container-fluid">
        <div class="container">
            <div class="row">

                <div class="tabs">
                    <ul class="tablist">
                        <li class="active"><a href="#tab-order" class="tab-link">SPOT Order</a></li>
                        <li><a href="#tab-balance" class="tab-link">SPOT Balance</a></li>
                    </ul>
                </div>
                <div class="tab-container">
                    <div class="tab-content active" id="tab-order">
                        <div id="message"></div>
                        <h3>SPOT Order</h3>
                        <div class="form-container">
                            <form id="form-buy" method="POST" action="" enctype="multipart/form-data">
                                <div class="table-responsive form-table">
                                    <table>
                                        <tr>
                                            <th>Crypto Pair</th>
                                            <td>
                                                <input class="input" name="symbol" id="input-symbol" value="" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Quantity</th>
                                            <td>
                                                <input class="input" name="quoteOrderQty" id="input-quoteorderqty" value="" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Order ID</th>
                                            <td>
                                                <input class="input" name="newClientOrderId" id="input-newclientorderid" value="<?php echo generateOrderID(); ?>" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="border: none;"></th>
                                            <td class="text-right" style="border: none; padding-top: 8px;">
                                                <input type="hidden" name="orderId" value="" />
                                                <button type="submit" class="btn btn-buysell" id="" data-action="buy">Buy</button>
                                                <button type="submit" class="btn btn-buysell" id="" data-action="sell">Sell</button>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </form>
                            <div class="result-table buy-table">
                                <div class="form-table">
                                    <table class="table-buy">

                                    </table>
                                </div>
                            </div>
                        </div>
                        <br>
                        <h3>SPOT Fix %</h3>
                        <div class="form-container">

                            <form id="form-oco" method="POST" action="" enctype="multipart/form-data">
                                <div class="table-responsive form-table">
                                    <table class="table-oco">
                                        <tr>
                                            <th>Crypto Pair</th>
                                            <th>Quantity</th>
                                            <th>Profit %</th>
                                            <th>Loss %</th>
                                            <th style="border: none;"></th>
                                        </tr>
                                        <tr>
                                            <td>
                                                <input class="input" name="symbol" id="input-symbol" value="" />
                                            </td>
                                            <td>
                                                <input class="input" name="quantity" id="input-quoteorderqty" value="" />
                                            </td>
                                            <td>
                                                <input class="input" name="profit" id="input-profit" value="" />
                                            </td>
                                            <td>
                                                <input class="input" name="loss" id="input-loss" value="" />
                                            </td>
                                            <td class="text-right" style="border: none;">
                                                <input type="hidden" name="price" value="" />

                                                <button type="button" class="btn" id="btn-oco" data-action="buyoco" disabled="disabled">Buy</button>
                                                <button type="button" class="btn" id="btn-ammend" data-action="ammend" data-type="" disabled="disabled">Ammend</button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="5" id="form-oco-message" style="border: none;"></td>
                                        </tr>
                                    </table>
                                </div>
                            </form>
                        </div>

                    </div>
                    <div class="tab-content" id="tab-balance">
                        <div id="message-balance">
                            <?php if (Config::$testMode) : ?>
                                <div class="message error">SAPI end points not supported on test mode</div>
                            <?php endif; ?>
                        </div>
                        <div class="form-container">
                            <form id="form-balance" method="POST" action="" enctype="multipart/form-data">
                                <div class="table-responsive form-table">
                                    <table>
                                        <tr>
                                            <th>Check Balance</th>
                                            <td class="text-center">
                                                <input type="hidden" name="type" id="input-type" value="SPOT" />
                                                <button type="submit" class="btn" id="btn-submit-form-balance">Check</button>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </form>

                            <div class="result-table balance-table">
                                <div class="form-table">
                                    <table>
                                        <!-- <tr>
                                            <th>Buyer Commission</th>
                                            <td id="cell-buyer-commission">0</td>
                                        </tr>
                                        <tr>
                                            <th>Seller Commission</th>
                                            <td id="cell-seller-commission">0</td>
                                        </tr>
                                        <tr>
                                            <th>Taker Commission</th>
                                            <td id="cell-seller-commission">0</td>
                                        </tr> -->
                                        <tr>
                                            <th>Total Asset of BTC</th>
                                            <td id="cell-totalAssetOfBtc">0</td>
                                        </tr>
                                    </table>
                                    <br>
                                    <h3>Balances</h3>
                                    <table class="table-balance">
                                        <tr>
                                            <td>Currency</th>
                                            <td>Free</td>
                                            <td>Locked</td>
                                        </tr>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="assets/js/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/script.js"></script>
</body>

</html>