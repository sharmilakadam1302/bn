'use strict';

const path = require("path");
const express = require('express');
const app = express().use(rawBody); // creates http server
const request = require('request');
const token = '133122'; // type here your verification token
const fetch = require('node-fetch');
const crypto = require('crypto');
const qs = require('qs');


const apiKey = "586YdCIu5vmjIJL9jRul1Htm1GI6ND1noqXGiFbzLoRwDg";
const apiSecret = "Tlcmg19g3kBdiDwSo1XcJa0yy21rsdQM";




function rawBody(req, res, next) {
    req.setEncoding('utf8');
    req.rawBody = '';
    req.on('data', function (chunk) {
        req.rawBody += chunk;
    });
    req.on('end', function () {
        next();
    });
}

// 0 current price, 1 action (buy or sell) buy - buy and create stop loss / sell - amend stop loss price, 2 comment future use, 3 xbusd, 4 quantity +, 5 stoploss, 6 orderN
//12001.0,buy,demo1,XBTUSD,13,11000,112 for buy
//12001.0,sell,demo1,XBTUSD,13,11300,112 fr sell


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, "index.html"));

});

app.post('/trade', (req, res) => {


    const verb = 'POST';
    const verb3 = 'DELETE';
    const path1 = '/api/v3/order';
    const path = '/sapi/v1/margin/order';
    const path0 = '/sapi/v1/margin/loan';
    const path00 = '/sapi/v1/margin/repay';
    const patht = '/sapi/v1/margin/isolated/transfer';




    const expires = Math.round(new Date().getTime() / 1000) + 60; // 1 min in the future


    var fields = req.rawBody.split(',');





    var curr = "";
    curr = fields[2];

    var orderN = "";
    orderN = fields[0];

    var flag = fields[4];

    var action = fields[1];


    var close = 0.000
    close = fields[6]

    var amt = 0.000
    amt = fields[5]

    var qty = 0;
    qty = fields[3];







    var today = new Date();

    var date = today.getFullYear() + '' + (today.getMonth() + 1) + '' + today.getDate();

    var time = today.getHours() + "" + today.getMinutes() + "" + today.getSeconds();

    var dateTime = date + 't' + time;

    console.log(dateTime);


    for (var i = 0; i < 1; i++) {


        if (action == 'buy' && flag == '5') {





            const data1 = {
                symbol: curr,
                // recvWindow: 20000,
                timestamp: Date.now(),
                side: "BUY",
                type: "MARKET",
                // timeInForce: "GTC",
                quoteOrderQty: qty,
                // quantity: qty,
                // price: close,
                // stopPrice: "",
                newClientOrderId: orderN,
            };

            const postBody1 = qs.stringify(data1);

            const signature1 = crypto.createHmac('sha256', apiSecret)
                .update(postBody1)
                .digest('hex');



            const headers1 = {
                'X-MBX-APIKEY': apiKey
            };




            const requestOptions1 = {
                headers: headers1,
                // Notice we are using testnet here. Switch to www to query the production site.
                url: 'https://api.binance.com' + path1 + '?' + postBody1 + '&signature=' + signature1,
                method: verb
            };



            request(requestOptions1, function (error, response, body) {
                if (error) { console.log(error); }
                console.log(body);
            });

        }






        res.send({
            result: 'success'
        });
        // res.json({"message" : "Hello World"});






    });

app.listen(process.env.PORT || 3000, () => console.log('My Webhook is listening'));