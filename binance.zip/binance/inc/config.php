<?php
namespace Binance\Inc;

class Config{
    static $testMode = true;

    private static $baseUrl = 'https://api.binance.com/'; 
    private static $baseUrlTest = 'https://testnet.binance.vision/';

    static function baseUrl(){
        if( Config::$testMode ){
            return Config::$baseUrlTest;
        }else{
            return Config::$baseUrl;
        }
    }

    // static $apiKey = 'JcjUeElW7aavvl9RqeyIiIq8nt1b8PJK3YBlKO900BgwT8NvD2yn408t0xBOLjZY';
    // static $apiSecret = 'uoq2klFOhH42wvc4vUA1v8oYS9v2l0IrgdWx0e3sJ7SOJg3IZNAAb18kVWMCHLP0';
    static $apiKey = 'Fmuh5ksdUybl7sMtPafCyxDDf4oM8r2IpVdgV6pgECrk9Wh8LBwHwcKsvzy634Pd';
    static $apiSecret = 'MKQ7r6aTgNcTDtEIwGaGQLA2jXRAob6TnG5wpDXNpV81C211yJl6shk6wTuInZKx';

    static $dbUser = 'root';
    static $dbPass = '';
    static $dbName = 'binance';
    static $dbHost = 'localhost';
    static $dbPort = '3306';
}
