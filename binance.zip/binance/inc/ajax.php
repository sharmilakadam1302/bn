<?php
namespace Binance\Inc;

require_once 'config.php';
require_once 'functions.php';
require_once 'db.php';

$db = new DB( Config::$dbHost, Config::$dbUser, Config::$dbPass, Config::$dbName, Config::$dbPort);

$GLOBALS['db'] = $db;

switch( $_GET['action'] ){
    case 'buy':
        $json = buy();
        break;
    case 'sell':
        $json = buy( true );
        break;
    case 'ammend':
        $json = ammend();
        break;
    case 'balance':
        $json = balance();
        break;
    case 'buyoco':
        $json = oco();
        break;
    case 'selloco':
        $json = oco( true );
        break;
    default:
        $json = array( 'status' => 'error', 'message' => 'No action provided', 'data' => $_POST );
        break;
}

header( 'Content-Type: application/json' );

echo json_encode( $json );
exit;

function oco( $sell = false ){
    if ( empty($_POST['symbol']) || empty($_POST['quantity']) || empty( $_POST['profit'] ) || empty( $_POST['loss'] )) {
        return array('status' => 'error', 'message' => 'Missing fields');
    }

    $params = array();

    $ts = (microtime(true) * 1000);
    $params['timestamp'] = number_format($ts, 0, '.', '');
    $params['symbol'] = trim($_POST['symbol']);
    $params['side'] = ($sell) ? 'SELL' : 'BUY';
    $params['quantity'] = trim($_POST['quantity']);

    $price = $_POST['price'] * ( 1 + (float)$_POST['profit'] / 100 );
    $params['price'] = $price;

    $stopPrice = $_POST['price'] * ( 1 - (float)$_POST['loss'] / 100 );
    $params['stopPrice'] = $stopPrice;

    $params['stopLimitTimeInForce'] = 'GTC';
    $params['stopLimitPrice'] = $_POST['price'] * 0.8;

    $params['listClientOrderId'] = generateOrderID();

    $query = http_build_query( $params, '', '&' );

    $signature = hash_hmac('sha256', $query, Config::$apiSecret);

    $params['signature'] = $signature;

    $query = http_build_query( $params );

    $url = Config::baseUrl() . 'api/v3/order/oco';
    $header = array('X-MBX-APIKEY: ' . Config::$apiKey);

    $response = curlPost($url, $query, $header);

    $json = array();

    if ($response) {
        if (isset($response['body']['msg']) && isset($response['body']['code'])) {
            $json['status'] = 'error';
            $json['message'] = $response['body']['msg'];
            $json['code'] = $response['body']['code'];
            $json['params'] = $params;
        } else if (isset($response['body'])) {
            $json['status'] = 'success';
            $json['data'] = $response['body'];

            global $db;

            $db->query("INSERT INTO `currency_order` SET clientOrderId = '" . $db->escape( trim( $params['listClientOrderId'] ) ) . "', type = 'oco', currency = '" . $db->escape( trim( $_POST['symbol'] ) ) . "', quantity = '" . $db->escape( trim( $_POST['quantity'] ) ) . "', response = '" . $db->escape( json_encode( $response['body'] ) ) . "', time = NOW()");
        }
    }

    if (!$json) {
        $json['status'] = 'error';
        $json['data'] = NULL;
        $json['message'] = 'Unknown error';
        $json['header'] = (isset($response['header'])) ? $response['header'] : NULL;
    }

    return $json;

    return array( 'status' => 'success', 'body' => $params );
}

function buy( $sell = false ){
    if( empty( $_POST['symbol'] ) || empty( $_POST['quoteOrderQty'] ) ){
        return array( 'status' => 'error', 'message' => 'Missing fields' );
    }

    $params = array();

    $ts = (microtime(true) * 1000);
    $params['timestamp'] = number_format($ts, 0, '.', '');
    $params['symbol'] = trim( $_POST['symbol'] );
    $params['quoteOrderQty'] = trim( $_POST['quoteOrderQty'] );
    $params['newClientOrderId'] = trim( $_POST['newClientOrderId'] );
    $params['side'] = ( $sell ) ? 'SELL' : 'BUY';
    $params['type'] = 'MARKET';

    $query = http_build_query( $params, '', '&' );

    $signature = hash_hmac('sha256', $query, Config::$apiSecret);

    $params['signature'] = $signature;

    $query = http_build_query( $params );

    $url = Config::baseUrl() . 'api/v3/order';
    $header = array( 'X-MBX-APIKEY: ' . Config::$apiKey );

    $response = curlPost( $url, $query, $header );

    $json = array();

    if( $response ){
        if( isset( $response['body']['msg'] ) && isset( $response['body']['code'] ) ){
            $json['status'] = 'error';
            $json['message'] = $response['body']['msg'];
            $json['code'] = $response['body']['code'];

        }else if( isset( $response['body'] ) ){
            $json['status'] = 'success';
            $json['data'] = $response['body'];

            global $db;

            $db->query( "INSERT INTO `currency_order` SET clientOrderId = '" . $db->escape( trim( $_POST['newClientOrderId'] ) ) . "', type = 'buy', currency = '" . $db->escape( trim( $_POST['symbol'] ) ) . "', quantity = '" . $db->escape( trim( $_POST['quoteOrderQty'] ) ) . "', response = '" . $db->escape( json_encode( $response['body'] ) ) . "', time = NOW()" );
        }
    }

    if (!$json) {
        $json['status'] = 'error';
        $json['data'] = NULL;
        $json['message'] = 'Unknown error';
        $json['header'] = (isset($response['header'])) ? $response['header'] : NULL;
    }

    return $json;
}

function ammend(){
    if( empty( $_POST['symbol'] ) || empty( $_POST['orderId'] ) ){
        return array( 'status' => 'error', 'message' => 'Missing fields' );
    }

    $params = array();

    $ts = (microtime(true) * 1000);
    $params['timestamp'] = number_format($ts, 0, '.', '');
    $params['symbol'] = trim($_POST['symbol']);
    $params['orderId'] = trim( $_POST['orderId'] );

    $query = http_build_query($params, '', '&');

    $signature = hash_hmac('sha256', $query, Config::$apiSecret);

    $params['signature'] = $signature;

    $query = http_build_query($params);

    $url = Config::baseUrl() . 'api/v3/order';
    $header = array('X-MBX-APIKEY: ' . Config::$apiKey);

    $response = curlPost($url, $query, $header, 'DELETE');

    $json = array();

    if ($response) {
        if (isset($response['body']['msg']) && isset($response['body']['code'])) {
            $json['status'] = 'error';
            $json['message'] = $response['body']['msg'];
            $json['code'] = $response['body']['code'];
        } else if (isset($response['body'])) {
            $json['status'] = 'success';
            $json['data'] = $response['body'];
            $json['updatedOrderId'] = generateOrderID();
            global $db;

            $db->query("INSERT INTO `currency_order` SET clientOrderId = '" . $db->escape(trim($_POST['newClientOrderId'])) . "', type = 'cancel', currency = '" . $db->escape(trim($_POST['symbol'])) . "', quantity = '" . $db->escape(trim($_POST['quoteOrderQty'])) . "', response = '" . $db->escape(json_encode($response['body'])) . "', time = NOW()");
        }
    }

    if (!$json) {
        $json['status'] = 'error';
        $json['data'] = NULL;
        $json['message'] = 'Unknown error';
        $json['header'] = (isset($response['header'])) ? $response['header'] : NULL;
    }

    return $json;
}

function balance(){
    $params = array();

    $ts = (microtime(true) * 1000);
    $params['timestamp'] = number_format($ts, 0, '.', '');
    
    // $params['type'] = ( isset( $_POST['type'] ) ) ? $_POST['type'] : 'spot';
    // $params['limit'] = 10;
    // $params['recvWindow'] = 20000;
    // $params['recvWindow'] = 10000;

    $query = http_build_query($params, '', '&');

    $signature = hash_hmac('sha256', $query, Config::$apiSecret );

    $url = Config::baseUrl() . 'sapi/v1/accountSnapshot?' . $query . '&signature=' . $signature;

    $response = curlGet( $url, array( 'X-MBX-APIKEY: ' . Config::$apiKey ) );

    $json = array();

    if( $response ){
        if( !empty( $response['body']['msg'] ) &&  $response['body']['code'] !== 200 ){
            $json['status'] = 'error';
            $json['message'] = $response['body']['msg'];
            $json['code'] = $response['body']['code'];

        }else if( isset( $response['body']['snapshotVos'] ) && is_array( $response['body']['snapshotVos'] ) ){
            $json['status'] = 'success';
            $json['data'] = $response['body']['snapshotVos'][0];
        }
    }

    if( !$json ){
        $json['status'] = 'error';
        $json['data'] = NULL;
        $json['message'] = 'Unknown error';
        $json['header'] = (isset($response['header'])) ? $response['header'] : NULL;
    }

    return $json;
}