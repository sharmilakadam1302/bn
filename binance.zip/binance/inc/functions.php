<?php
namespace Binance\Inc;

function generateOrderID(){
    $alphabets = range('a', 'z');
    $id = 'ORD' . date( 'ymdhis', time() );

    for( $i = 0; $i < 8; $i++ ){
        $id .= $alphabets[ rand( 0, 25 ) ];
    }

    return $id;
}

function curlGet( $url, $headers = array() ){
    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, trim($url));
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    curl_setopt( $c, CURLOPT_USERAGENT, 'User-Agent: Mozilla/4.0 (compatible; PHP Binance API)' );
    curl_setopt( $c, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt( $c, CURLOPT_HEADER, true);

    if( $headers ){
        curl_setopt( $c, CURLOPT_HTTPHEADER, $headers );
    }

    $response = curl_exec($c);

    if( !$response ){
        return false;
    }

    $header_size = curl_getinfo( $c, CURLINFO_HEADER_SIZE);
    $header = getHeader( $response );
    $response = substr( $response, $header_size);

    curl_close($c);

    $json = json_decode( $response, true);

    return array(
        'header' => $header,
        'body' => $json
    );
}

function curlPost( $url, $data, $headers = array(), $type = false ){
    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, trim($url));
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    curl_setopt( $c, CURLOPT_POST, true );
    curl_setopt( $c, CURLOPT_POSTFIELDS, $data );
    curl_setopt( $c, CURLOPT_USERAGENT, 'User-Agent: Mozilla/4.0 (compatible; PHP Binance API)' );
    curl_setopt( $c, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt( $c, CURLOPT_HEADER, true);

    if( $type ){
        curl_setopt( $c, CURLOPT_CUSTOMREQUEST, $type );
    }

    if( $headers ){
        curl_setopt( $c, CURLOPT_HTTPHEADER, $headers );
    }

    $response = curl_exec($c);

    if (!$response) {
        return false;
    }

    $header_size = curl_getinfo( $c, CURLINFO_HEADER_SIZE);
    $header = getHeader( $response );
    $response = substr( $response, $header_size);

    curl_close($c);

    $json = json_decode( $response, true);

    return array(
        'header' => $header,
        'body' => $json
    );
}

function getHeader( $str ){
    $headers = array();
    $header_text = substr($str, 0, strpos($str, "\r\n\r\n"));

    foreach (explode("\r\n", $header_text) as $i => $line)
        if ($i === 0)
            $headers['http_code'] = $line;
        else {
            list($key, $value) = explode(': ', $line);
            $headers[$key] = $value;
        }

    return $headers;
}