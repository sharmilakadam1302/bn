const dataS = {
    symbol: curr,
    // recvWindow: 20000,
    timestamp: Date.now(),
    side: "SELL",
    stopLimitPrice: parseFloat(obj.fills[0].price * 0.80).toFixed(prec),

    // type: "STOP_LOSS_LIMIT",
    stopLimitTimeInForce: "GTC",
    quantity: parseFloat(obj.executedQty).toFixed(4),
    price: parseFloat(obj.fills[0].price * (1 + gain / 100)).toFixed(prec),
    stopPrice: parseFloat(obj.fills[0].price * 0.985).toFixed(prec),
    listClientOrderId: orderN,
};